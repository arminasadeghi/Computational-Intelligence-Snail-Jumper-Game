global_variables = {
    'events': None,
    'obstacle_groups': None,
    'title': "Snail Jumper",
    'screen_width': 604,
    'screen_height': 800,
}
